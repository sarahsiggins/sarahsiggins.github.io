const data = {
    portfolios: [
        {
            techStack: "HTML, CSS, JS",
            title: "Title 1",
            githubLink: "#",
            projectLink: "#",
            imgLink: "images/portfolio/beach.jpg"
        },
        {
            techStack: "HTML, CSS, JS",
            title: "Title 2",
            githubLink: "#",
            projectLink: "#",
            imgLink: "images/portfolio/sunset.jpg"
        },
        {
            techStack: "HTML, CSS, JS",
            title: "Title 3",
            githubLink: "#",
            projectLink: "#",
            imgLink: "images/portfolio/mountain.jpg"
        },
        {
            techStack: "HTML, CSS, JS",
            title: "Title 4",
            githubLink: "#",
            projectLink: "#",
            imgLink: "images/portfolio/polaroid.jpg"
        },
        {
            techStack: "HTML, CSS, JS",
            title: "Title 5",
            githubLink: "#",
            projectLink: "#",
            imgLink: "images/portfolio/bag.jpg"
        },
        {
            techStack: "HTML, CSS, JS",
            title: "Title 6",
            githubLink: "#",
            projectLink: "#",
            imgLink: "images/portfolio/bicycle.jpg"
        }
    ]
}
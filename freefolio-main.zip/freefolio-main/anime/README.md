# Anime - Free Portfolio Website Templates

An Anime Portfolio Template for you!

![Anime - Screenshot](./img/anime.png "Anime - Screenshot")

## ⚡ Features

✅ Fast

✅ FREE

✅ Mobile Responsive

✅ SEO Friendly

✅ Compatible with any web server

✅ 0 Dependencies

## 📃 License

[![](https://img.shields.io/static/v1?label=LICENSE&message=MIT&style=for-the-badge&color=blueviolet)](https://opensource.org/licenses/MIT)

## 🤔 I am not a web developer, how do I setup my portfolio website?

> Need help with setting up your portfolio website?

> Contact us at https://ossph.org
